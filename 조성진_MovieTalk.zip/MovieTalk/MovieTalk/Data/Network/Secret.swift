//
//  Secret.swift
//  MovieTalk
//
//  Created by Alex Cho on 2023/11/20.
//

import Foundation
enum Secret{
//    static let port = "27812" //port auth test
    static let key = "UCDBhLIHZ7"
    static let port = "27820" //port dev
    static let baseURL = URL(string: "http://lslp.sesac.kr:\(port)")!
    static let baseURLString =  "http://lslp.sesac.kr:\(port)/"
    static let imageQuery = "?product_id=mtSNS"
    
    static let tmdbKey = "42de580fd67c2991513fc60dfa628a99"
    static let tmdbBaseURL = URL(string: "https://api.themoviedb.org/3/")!
    //MARK: ⚠️ original 사이즈에서 w500으로 제한했더니 되었다. 진짜 이것 때문인가? 오리널일땐 몇 10메가이상이였던 파일 데이터가 1메가 이하로 줄었다.
    
//        static let imageBaseURL = "https://image.tmdb.org/t/p/original" //10메가 이상
//    static let imageBaseURL = "https://image.tmdb.org/t/p/w780" //2메가 정도
    static let imageBaseURL = "https://image.tmdb.org/t/p/w500" //1메가보다 작음

    static func getEndPointImageURL(_ endpoint: String) -> URL {
        return URL(string: imageBaseURL + endpoint)!
    }
}
